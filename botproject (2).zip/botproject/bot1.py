import logging
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    Updater, CommandHandler, CallbackQueryHandler, CallbackContext,
    ConversationHandler, MessageHandler, Filters
)
import sqlite3
import random
from enum import Enum


logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s', level=logging.INFO)
logger = logging.getLogger(__name__)

TOKEN = "7619484304:AAHmeizW00cXqFMc5KYzD4B6J6zcxufnFVU"
CURRENCY_NAME = "коины"

CHOOSING, PLAYING_GAME, PLAYING_BLACKJACK, PLAYING_UNO = range(4)


class BlackjackState(Enum):
    PLAYER_TURN = 1
    DEALER_TURN = 2
    GAME_OVER = 3


class UnoState(Enum):
    PLAYER_TURN = 1
    BOT_TURN = 2
    GAME_OVER = 3


def init_db():
    conn = sqlite3.connect('game_bot.db')
    cursor = conn.cursor()
    cursor.execute(
        'CREATE TABLE IF NOT EXISTS users (user_id INTEGER PRIMARY KEY, username TEXT, balance INTEGER DEFAULT 0)')
    conn.commit()
    conn.close()


def get_user(user_id):
    conn = sqlite3.connect('game_bot.db')
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM users WHERE user_id = ?', (user_id,))
    user = cursor.fetchone()
    conn.close()
    return {'user_id': user[0], 'username': user[1], 'balance': user[2]} if user else None


def create_user(user_id, username):
    conn = sqlite3.connect('game_bot.db')
    cursor = conn.cursor()
    cursor.execute('INSERT INTO users (user_id, username) VALUES (?, ?)', (user_id, username))
    conn.commit()
    conn.close()


def update_balance(user_id, amount):
    conn = sqlite3.connect('game_bot.db')
    cursor = conn.cursor()
    cursor.execute('UPDATE users SET balance = balance + ? WHERE user_id = ?', (amount, user_id))
    conn.commit()
    conn.close()


def start(update: Update, context: CallbackContext):
    user = update.effective_user
    if get_user(user.id) is None:
        create_user(user.id, user.username or user.first_name)
    return show_main_menu(update, context)


def show_main_menu(update: Update, context: CallbackContext):
    keyboard = [
        [InlineKeyboardButton("🎮 Игры", callback_data='games')],
        [InlineKeyboardButton("💰 Баланс", callback_data='balance')],
        [InlineKeyboardButton("ℹ️ Помощь", callback_data='help')]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    if update.callback_query:
        update.callback_query.answer()
        update.callback_query.edit_message_text(text="Главное меню:", reply_markup=reply_markup)
    else:
        update.message.reply_text(text="Главное меню:", reply_markup=reply_markup)
    return CHOOSING


def show_balance(update: Update, context: CallbackContext):
    user = get_user(update.effective_user.id)
    update.callback_query.answer()
    update.callback_query.edit_message_text(
        text=f"Ваш баланс: {user['balance']} {CURRENCY_NAME}",
        reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("Назад", callback_data='back')]])
    )
    return CHOOSING


def show_help(update: Update, context: CallbackContext):
    update.callback_query.answer()
    update.callback_query.edit_message_text(
        text=f"🤖 Бот с мини-играми\n\nДоступные игры:\n- Крестики-нолики\n- Угадай число\n- Блэкджек\n- Uno\n\nВалюта: {CURRENCY_NAME}",
        reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("Назад", callback_data='back')]])
    )
    return CHOOSING


def show_games_menu(update: Update, context: CallbackContext):
    keyboard = [
        [InlineKeyboardButton("❌⭕ Крестики-нолики", callback_data='tic_tac_toe')],
        [InlineKeyboardButton("🔢 Угадай число", callback_data='guess_number')],
        [InlineKeyboardButton("🃏 Блэкджек", callback_data='blackjack')],
        [InlineKeyboardButton("🃏 Uno", callback_data='uno')],
        [InlineKeyboardButton("Назад", callback_data='back')]
    ]
    update.callback_query.answer()
    update.callback_query.edit_message_text(
        text="Выберите игру:",
        reply_markup=InlineKeyboardMarkup(keyboard)
    )
    return CHOOSING


class TicTacToe:
    def __init__(self):
        self.board = [[' ' for _ in range(3)] for _ in range(3)]
        self.player_symbol = 'X'
        self.current_player = 'X'

    def make_move(self, row, col, update: Update, context: CallbackContext):
        if self.board[row][col] == ' ':
            self.board[row][col] = self.current_player
            if self.check_winner(update, context):
                return True
            self.current_player = 'O' if self.current_player == 'X' else 'X'
            return True
        return False

    def check_winner(self, update: Update, context: CallbackContext):
        for row in self.board:
            if row[0] == row[1] == row[2] != ' ':
                self.end_game(update, context, row[0])
                return True
        for col in range(3):
            if self.board[0][col] == self.board[1][col] == self.board[2][col] != ' ':
                self.end_game(update, context, self.board[0][col])
                return True
        if self.board[0][0] == self.board[1][1] == self.board[2][2] != ' ':
            self.end_game(update, context, self.board[0][0])
            return True
        if self.board[0][2] == self.board[1][1] == self.board[2][0] != ' ':
            self.end_game(update, context, self.board[0][2])
            return True
        if all(self.board[row][col] != ' ' for row in range(3) for col in range(3)):
            self.end_game(update, context, 'Draw')
            return True
        return False

    def end_game(self, update: Update, context: CallbackContext, winner):
        user_id = update.effective_user.id
        if winner == 'X':
            update_balance(user_id, 10)
            text = "Вы победили! +10 коинов"
        elif winner == 'O':
            text = "Бот победил!"
        else:
            update_balance(user_id, 5)
            text = "Ничья! +5 коинов"

        query = update.callback_query
        query.answer(text)
        query.edit_message_text(
            text=self.get_board(),
            reply_markup=self.get_markup()
        )

        context.job_queue.run_once(
            lambda ctx: show_main_menu(update, context),
            2,
            name=str(user_id)
        )
        return ConversationHandler.END

    def get_board(self):
        text = "Крестики-нолики (Вы - X)\n\n"
        for row in self.board:
            text += " | ".join(row) + "\n"
            text += "-" * 9 + "\n"
        return text

    def get_markup(self):
        keyboard = []
        for row in range(3):
            keyboard_row = []
            for col in range(3):
                keyboard_row.append(InlineKeyboardButton(self.board[row][col], callback_data=f"ttt_{row}_{col}"))
            keyboard.append(keyboard_row)
        keyboard.append([InlineKeyboardButton("Назад", callback_data='back')])
        return InlineKeyboardMarkup(keyboard)


def handle_tic_tac_toe(update: Update, context: CallbackContext):
    query = update.callback_query
    data = query.data

    if data == 'back':
        context.user_data.pop('game', None)
        return show_main_menu(update, context)

    if data.startswith('ttt_'):
        game = context.user_data['game']

        if game.current_player != 'X':
            query.answer("Сейчас ход бота!")
            return PLAYING_GAME

        _, row, col = data.split('_')
        row, col = int(row), int(col)

        if game.make_move(row, col, update, context):
            if not game.check_winner(update, context) and game.current_player == 'O':
                empty = [(r, c) for r in range(3) for c in range(3) if game.board[r][c] == ' ']
                if empty:
                    r, c = random.choice(empty)
                    game.make_move(r, c, update, context)
                    game.check_winner(update, context)

            query.answer()
            query.edit_message_text(
                text=game.get_board(),
                reply_markup=game.get_markup()
            )

    return PLAYING_GAME


class Blackjack:
    def __init__(self, bet_amount):
        self.deck = self.create_deck()
        self.player_hand = []
        self.dealer_hand = []
        self.state = BlackjackState.PLAYER_TURN
        self.bet_amount = bet_amount
        self.deal_initial_cards()

    def create_deck(self):
        suits = ['♥', '♦', '♣', '♠']
        ranks = ['2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K', 'A']
        deck = [{'rank': rank, 'suit': suit} for suit in suits for rank in ranks]
        random.shuffle(deck)
        return deck

    def deal_initial_cards(self):
        self.player_hand = [self.deck.pop(), self.deck.pop()]
        self.dealer_hand = [self.deck.pop(), self.deck.pop()]

    def calculate_hand_value(self, hand):
        value = 0
        aces = 0

        for card in hand:
            rank = card['rank']
            if rank in ['J', 'Q', 'K']:
                value += 10
            elif rank == 'A':
                value += 11
                aces += 1
            else:
                value += int(rank)

        while value > 21 and aces > 0:
            value -= 10
            aces -= 1

        return value

    def hit(self):
        self.player_hand.append(self.deck.pop())
        if self.calculate_hand_value(self.player_hand) > 21:
            self.state = BlackjackState.GAME_OVER

    def stand(self):
        self.state = BlackjackState.DEALER_TURN
        while self.calculate_hand_value(self.dealer_hand) < 17:
            self.dealer_hand.append(self.deck.pop())
        self.state = BlackjackState.GAME_OVER

    def determine_winner(self):
        player_value = self.calculate_hand_value(self.player_hand)
        dealer_value = self.calculate_hand_value(self.dealer_hand)

        if player_value > 21:
            return "dealer"
        elif dealer_value > 21:
            return "player"
        elif player_value > dealer_value:
            return "player"
        elif dealer_value > player_value:
            return "dealer"
        else:
            return "push"

    def get_game_text(self, show_all_dealer_cards=False):
        text = f"🃏 Блэкджек (Ставка: {self.bet_amount} {CURRENCY_NAME})\n\n"

        text += "Дилер:\n"
        if show_all_dealer_cards or self.state == BlackjackState.GAME_OVER:
            text += " ".join(f"{card['rank']}{card['suit']}" for card in self.dealer_hand)
            text += f" = {self.calculate_hand_value(self.dealer_hand)}\n"
        else:
            text += f"{self.dealer_hand[0]['rank']}{self.dealer_hand[0]['suit']} ?\n"

        text += "\nВы:\n"
        text += " ".join(f"{card['rank']}{card['suit']}" for card in self.player_hand)
        text += f" = {self.calculate_hand_value(self.player_hand)}\n"

        return text

    def get_markup(self):
        keyboard = []
        if self.state == BlackjackState.PLAYER_TURN:
            keyboard.append([
                InlineKeyboardButton("✅ Еще", callback_data='bj_hit'),
                InlineKeyboardButton("✋ Хватит", callback_data='bj_stand')
            ])
        keyboard.append([InlineKeyboardButton("Назад", callback_data='back')])
        return InlineKeyboardMarkup(keyboard)


class UnoGame:
    def __init__(self):
        self.colors = ['🔴', '🟢', '🟡', '🔵']
        self.values = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '🚫', '🔄', '+2']
        self.special_cards = ['🎨', '+4']

        self.create_deck()
        self.shuffle_deck()
        self.discard_pile = []
        self.player_hand = []
        self.bot_hand = []
        self.current_color = None
        self.current_value = None
        self.current_player = 'player' if random.random() > 0.5 else 'bot'
        self.state = UnoState.PLAYER_TURN if self.current_player == 'player' else UnoState.BOT_TURN

        self.deal_initial_cards()
        self.start_game()

    def create_deck(self):
        self.deck = []
        for color in self.colors:
            self.deck.append({'color': color, 'value': '0', 'special': False})
            for value in self.values[1:]:
                self.deck.append({'color': color, 'value': value, 'special': False})
                self.deck.append({'color': color, 'value': value, 'special': False})

        for _ in range(4):
            self.deck.append({'color': '⚫', 'value': '🎨', 'special': True})
            self.deck.append({'color': '⚫', 'value': '+4', 'special': True})

    def shuffle_deck(self):
        random.shuffle(self.deck)

    def deal_initial_cards(self):
        for _ in range(7):
            self.player_hand.append(self.deck.pop())
            self.bot_hand.append(self.deck.pop())

    def start_game(self):
        while True:
            if not self.deck:
                self.reshuffle_discard_pile()
            card = self.deck.pop()
            if not card['special']:
                self.discard_pile.append(card)
                self.current_color = card['color']
                self.current_value = card['value']
                break
            else:
                self.deck.insert(0, card)

    def reshuffle_discard_pile(self):
        if not self.discard_pile:
            return

        last_card = self.discard_pile[-1]
        self.discard_pile = self.discard_pile[:-1]
        self.deck = self.discard_pile
        self.shuffle_deck()
        self.discard_pile = [last_card]

    def draw_card(self, hand):
        if not self.deck:
            self.reshuffle_discard_pile()
            if not self.deck:
                return False
        hand.append(self.deck.pop())
        return True

    def can_play_card(self, card):
        if card['color'] == '⚫':
            return True
        return card['color'] == self.current_color or card['value'] == self.current_value

    def play_card(self, card_index, hand):
        if card_index < 0 or card_index >= len(hand):
            return False

        card = hand[card_index]
        if not self.can_play_card(card):
            return False

        played_card = hand.pop(card_index)
        self.discard_pile.append(played_card)

        if played_card['color'] != '⚫':
            self.current_color = played_card['color']
        self.current_value = played_card['value']

        if played_card['value'] == '🚫':
            self.current_player = 'bot' if self.current_player == 'player' else 'player'
        elif played_card['value'] == '🔄':
            self.current_player = 'bot' if self.current_player == 'player' else 'player'
        elif played_card['value'] == '+2':
            for _ in range(2):
                self.draw_card(self.bot_hand if self.current_player == 'player' else self.player_hand)
        elif played_card['value'] == '+4':
            for _ in range(4):
                self.draw_card(self.bot_hand if self.current_player == 'player' else self.player_hand)
            if self.current_player == 'player':
                return 'choose_color'

        if played_card['value'] not in ['🚫', '🔄', '+2', '+4']:
            self.current_player = 'bot' if self.current_player == 'player' else 'player'

        return True

    def bot_move(self):
        for i, card in enumerate(self.bot_hand):
            if self.can_play_card(card):
                result = self.play_card(i, self.bot_hand)
                if result == 'choose_color':
                    color_counts = {color: 0 for color in self.colors}
                    for card in self.bot_hand:
                        if card['color'] in color_counts:
                            color_counts[card['color']] += 1
                    chosen_color = max(color_counts, key=color_counts.get)
                    self.current_color = chosen_color
                return True

        if not self.draw_card(self.bot_hand):
            return False

        if self.can_play_card(self.bot_hand[-1]):
            result = self.play_card(len(self.bot_hand) - 1, self.bot_hand)
            if result == 'choose_color':
                color_counts = {color: 0 for color in self.colors}
                for card in self.bot_hand:
                    if card['color'] in color_counts:
                        color_counts[card['color']] += 1
                chosen_color = max(color_counts, key=color_counts.get)
                self.current_color = chosen_color
            return True

        return True

    def check_game_over(self):
        if not self.player_hand:
            return 'player'
        elif not self.bot_hand:
            return 'bot'
        return None

    def get_game_text(self):
        text = f"🃏 Uno (Ход: {'Ваш' if self.current_player == 'player' else 'Бота'})\n\n"
        text += f"Текущая карта: {self.current_color}{self.current_value}\n\n"
        text += "Ваши карты:\n"
        for i, card in enumerate(self.player_hand):
            text += f"{i + 1}. {card['color']}{card['value']}\n"
        return text

    def get_markup(self):
        keyboard = []
        row = []
        for i, card in enumerate(self.player_hand):
            if self.can_play_card(card):
                row.append(InlineKeyboardButton(f"{i + 1}", callback_data=f"uno_play_{i}"))
                if len(row) == 3:
                    keyboard.append(row)
                    row = []
        if row:
            keyboard.append(row)

        keyboard.append([InlineKeyboardButton("Взять карту", callback_data='uno_draw')])

        keyboard.append([InlineKeyboardButton("Назад", callback_data='back')])

        return InlineKeyboardMarkup(keyboard)


def start_tic_tac_toe(update: Update, context: CallbackContext):
    context.user_data['game'] = TicTacToe()
    game = context.user_data['game']

    if game.player_symbol == 'O':
        empty = [(r, c) for r in range(3) for c in range(3) if game.board[r][c] == ' ']
        if empty:
            r, c = random.choice(empty)
            game.make_move(r, c, update, context)

    update.callback_query.answer()
    update.callback_query.edit_message_text(text=game.get_board(), reply_markup=game.get_markup())
    return PLAYING_GAME


def start_blackjack(update: Update, context: CallbackContext):
    update.callback_query.answer()
    update.callback_query.edit_message_text(
        text="Введите сумму ставки:",
        reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("Назад", callback_data='back')]])
    )
    return PLAYING_BLACKJACK


def start_uno(update: Update, context: CallbackContext):
    context.user_data['uno'] = UnoGame()
    game = context.user_data['uno']

    if game.current_player == 'bot':
        game.bot_move()
        winner = game.check_game_over()
        if winner:
            return end_uno_game(update, context, winner)

    update.callback_query.answer()
    update.callback_query.edit_message_text(
        text=game.get_game_text(),
        reply_markup=game.get_markup()
    )
    return PLAYING_UNO


def end_uno_game(update: Update, context: CallbackContext, winner):
    user_id = update.effective_user.id
    if winner == 'player':
        update_balance(user_id, 15)
        text = "Вы победили! +15 коинов"
    else:
        text = "Бот победил!"

    update.callback_query.answer(text)
    context.user_data.pop('uno', None)
    return show_main_menu(update, context)


def handle_blackjack_bet(update: Update, context: CallbackContext):
    user_id = update.effective_user.id
    user = get_user(user_id)

    try:
        bet_amount = int(update.message.text)
        if bet_amount <= 0:
            update.message.reply_text("Ставка должна быть положительным числом!")
            return PLAYING_BLACKJACK
        if bet_amount > user['balance']:
            update.message.reply_text("У вас недостаточно средств для такой ставки!")
            return PLAYING_BLACKJACK

        context.user_data['blackjack'] = Blackjack(bet_amount)
        game = context.user_data['blackjack']

        update_balance(user_id, -bet_amount)

        update.message.reply_text(
            text=game.get_game_text(),
            reply_markup=game.get_markup()
        )
        return PLAYING_GAME
    except ValueError:
        update.message.reply_text("Пожалуйста, введите число!")
        return PLAYING_BLACKJACK


def handle_blackjack(update: Update, context: CallbackContext):
    query = update.callback_query
    data = query.data

    if data == 'back':
        return show_main_menu(update, context)

    game = context.user_data['blackjack']
    user_id = update.effective_user.id

    if data == 'bj_hit':
        game.hit()
    elif data == 'bj_stand':
        game.stand()

    if game.state == BlackjackState.GAME_OVER:
        result = game.determine_winner()
        if result == "player":
            win_amount = game.bet_amount * 2
            update_balance(user_id, win_amount)
            result_text = f"Вы выиграли! +{win_amount} {CURRENCY_NAME}"
        elif result == "dealer":
            result_text = f"Вы проиграли! -{game.bet_amount} {CURRENCY_NAME}"
        else:
            update_balance(user_id, game.bet_amount)
            result_text = f"Ничья! Возврат ставки"

        query.answer(result_text)

    query.edit_message_text(
        text=game.get_game_text(show_all_dealer_cards=True),
        reply_markup=game.get_markup()
    )

    if game.state == BlackjackState.GAME_OVER:
        context.user_data.pop('blackjack', None)
        return show_main_menu(update, context)

    return PLAYING_GAME


def handle_uno(update: Update, context: CallbackContext):
    query = update.callback_query
    data = query.data

    if data == 'back':
        return show_main_menu(update, context)

    game = context.user_data['uno']

    if data.startswith('uno_play_'):
        card_index = int(data.split('_')[2])
        result = game.play_card(card_index, game.player_hand)

        if result == 'choose_color':
            keyboard = [
                [InlineKeyboardButton("🔴", callback_data='uno_color_red'),
                 InlineKeyboardButton("🟢", callback_data='uno_color_green')],
                [InlineKeyboardButton("🟡", callback_data='uno_color_yellow'),
                 InlineKeyboardButton("🔵", callback_data='uno_color_blue')],
                [InlineKeyboardButton("Назад", callback_data='back')]
            ]
            query.edit_message_text(
                text="Выберите цвет:",
                reply_markup=InlineKeyboardMarkup(keyboard)
            )
            return PLAYING_UNO

        winner = game.check_game_over()
        if winner:
            return end_uno_game(update, context, winner)

        if game.current_player == 'bot':
            game.bot_move()
            winner = game.check_game_over()
            if winner:
                return end_uno_game(update, context, winner)

    elif data.startswith('uno_color_'):
        color_map = {
            'red': '🔴',
            'green': '🟢',
            'yellow': '🟡',
            'blue': '🔵'
        }
        color = data.split('_')[2]
        game.current_color = color_map[color]

        if game.current_player == 'bot':
            game.bot_move()
            winner = game.check_game_over()
            if winner:
                return end_uno_game(update, context, winner)

    elif data == 'uno_draw':
        game.draw_card(game.player_hand)
        if game.can_play_card(game.player_hand[-1]):
            query.answer("Вы можете сыграть эту карту!")
        else:
            game.current_player = 'bot'
            game.bot_move()
            winner = game.check_game_over()
            if winner:
                return end_uno_game(update, context, winner)

    query.edit_message_text(
        text=game.get_game_text(),
        reply_markup=game.get_markup()
    )
    return PLAYING_UNO


def handle_tic_tac_toe(update: Update, context: CallbackContext):
    query = update.callback_query
    data = query.data

    if data == 'back':
        return show_main_menu(update, context)

    if data.startswith('ttt_'):
        _, row, col = data.split('_')
        game = context.user_data['game']

        if game.make_move(int(row), int(col), update, context):
            if game.current_player == 'O' and not game.check_winner(update, context):
                empty = [(r, c) for r in range(3) for c in range(3) if game.board[r][c] == ' ']
                if empty:
                    r, c = random.choice(empty)
                    game.make_move(r, c, update, context)

            query.answer()
            query.edit_message_text(text=game.get_board(), reply_markup=game.get_markup())

    return PLAYING_GAME


def handle_callback(update: Update, context: CallbackContext):
    query = update.callback_query
    data = query.data

    query.answer()

    if data == 'games':
        return show_games_menu(update, context)
    elif data == 'balance':
        return show_balance(update, context)
    elif data == 'help':
        return show_help(update, context)
    elif data == 'back':
        return show_main_menu(update, context)
    elif data == 'tic_tac_toe':
        return start_tic_tac_toe(update, context)
    elif data == 'blackjack':
        return start_blackjack(update, context)
    elif data == 'uno':
        return start_uno(update, context)
    return CHOOSING


def main():
    init_db()
    updater = Updater(TOKEN, use_context=True)

    conv_handler = ConversationHandler(
        entry_points=[CommandHandler('start', start)],
        states={
            CHOOSING: [CallbackQueryHandler(handle_callback)],
            PLAYING_GAME: [
                CallbackQueryHandler(handle_tic_tac_toe, pattern='^ttt_'),
                CallbackQueryHandler(handle_blackjack, pattern='^bj_'),
                CallbackQueryHandler(handle_callback)
            ],
            PLAYING_BLACKJACK: [
                MessageHandler(Filters.text & ~Filters.command, handle_blackjack_bet),
                CallbackQueryHandler(handle_callback)
            ],
            PLAYING_UNO: [
                CallbackQueryHandler(handle_uno, pattern='^uno_'),
                CallbackQueryHandler(handle_callback)
            ]
        },
        fallbacks=[CommandHandler('start', start)]
    )

    updater.dispatcher.add_handler(conv_handler)
    updater.start_polling()
    updater.idle()


if __name__ == '__main__':
    main()